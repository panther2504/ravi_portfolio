let percentHtml = document.getElementById("percentHtml");
let html = 0;
setInterval(() => {
  if (html == 70) {
    clearInterval();
  } else {
    html += 1;
    percentHtml.innerHTML = html + "%";
  }
}, 28);
